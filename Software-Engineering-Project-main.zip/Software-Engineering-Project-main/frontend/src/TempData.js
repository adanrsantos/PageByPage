export const posts = [
    {
        id: 1,
        title: "Monster",
        img: "https://cdn.myanimelist.net/images/manga/3/258224l.jpg"
    },
    {
        id: 2,
        title: "Berserk",
        img: "https://cdn.myanimelist.net/images/manga/1/157897l.jpg"
    },
    {
        id: 3,
        title: "20th Century Boys",
        img: "https://cdn.myanimelist.net/images/manga/5/260006l.jpg"
    },
    {
        id: 4,
        title: "Yokohama Kaidashi Kikou",
        img: "https://cdn.myanimelist.net/images/manga/1/171813l.jpg"
    },
    {
        id: 5,
        title: "Hajime no Ippo",
        img: "https://cdn.myanimelist.net/images/manga/2/250313l.jpg"
    },
    {
        id: 6,
        title: "Full Moon wo Sagashite",
        img: "https://cdn.myanimelist.net/images/manga/3/175970l.jpg"
    },
    {
        id: 7,
        title: "Tsubana: RESERVoir ChronNiCLE",
        img: "https://cdn.myanimelist.net/images/manga/1/272410l.jpg"
    },
    {
        id: 8,
        title: "xxxHolic",
        img: "https://cdn.myanimelist.net/images/manga/3/217533l.jpg"
    },
    {
        id: 9,
        title: "Naruto",
        img: "https://cdn.myanimelist.net/images/manga/3/249658l.jpg"
    },
    {
        id: 10,
        title: "Bleach",
        img: "https://cdn.myanimelist.net/images/manga/3/180031l.jpg"
    },
    {
        id: 11,
        title: "One Piece",
        img: "https://cdn.myanimelist.net/images/manga/2/253146l.jpg"
    },
    {
        id: 12,
        title: "Rave",
        img: "https://cdn.myanimelist.net/images/manga/3/255624l.jpg"
    },

    {
        id: 13,
        title: "Mahou Sensei Negima!",
        img: "https://cdn.myanimelist.net/images/manga/1/259286l.jpg"
    },
    {
        id: 14,
        title: "Death Note",
        img: "https://cdn.myanimelist.net/images/manga/1/258245l.jpg"
    },
    {
        id: 15,
        title: "GetBackers",
        img: "https://cdn.myanimelist.net/images/manga/1/169369l.jpg"
    },
    {
        id: 16,
        title: "Fullmetal Alchemist",
        img: "https://cdn.myanimelist.net/images/manga/3/243675l.jpg"
    },
    {
        id: 17,
        title: "Hunter x Hunter",
        img: "https://cdn.myanimelist.net/images/manga/2/253119l.jpg"
    },
]