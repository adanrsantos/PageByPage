

const Settings = () => {
    return(
        <p>Settings</p>
    );
}

export default Settings;