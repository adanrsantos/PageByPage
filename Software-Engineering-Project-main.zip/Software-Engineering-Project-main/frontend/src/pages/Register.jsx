import RForm from "../components/RegisterComp/RForm";

const Register = () => {
    return (
        <div className="Register">
            <RForm />
        </div>
    );
}

export default Register